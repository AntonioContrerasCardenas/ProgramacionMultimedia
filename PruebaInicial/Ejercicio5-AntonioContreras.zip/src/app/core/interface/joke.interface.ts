export interface JokeInterface {
  setup: string;
  punchline: string;
}
